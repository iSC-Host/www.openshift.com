<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>301 Moved Permanently</title>
</head><body>
<h1>Moved Permanently</h1>
<p>The document has moved <a href="https://www.openshift.com/app/assets/modernizr.min-8bb4e7a407c7157e8ecdc555827d25a7.js">here</a>.</p>
<hr>
<address>Apache/2.2.15 (Red Hat) Server at openshift.com Port 443</address>
</body></html>
